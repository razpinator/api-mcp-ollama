using Microsoft.AspNetCore.Mvc;
using OllamaMcpBridge.Models;
using OllamaMcpBridge.Services;

namespace OllamaMcpBridge.Controllers;

[ApiController]
[Route("api/mcp")]
[Produces("application/json")]
public class McpController : ControllerBase
{
    private readonly IMcpService _mcpService;
    private readonly ILogger<McpController> _logger;

    public McpController(IMcpService mcpService, ILogger<McpController> logger)
    {
        _mcpService = mcpService;
        _logger = logger;
    }

    /// <summary>
    /// Get list of available MCP tools
    /// </summary>
    [HttpGet("tools")]
    public async Task<IActionResult> GetTools()
    {
        try
        {
            if (!_mcpService.IsConnected)
            {
                return StatusCode(503, new ListResponse<McpTool>
                {
                    Success = false,
                    Error = "MCP server not connected",
                    Items = new List<McpTool>(),
                    Count = 0
                });
            }

            var tools = await _mcpService.ListToolsAsync();
            
            var response = new ListResponse<McpTool>
            {
                Success = true,
                Items = tools,
                Count = tools.Count
            };

            _logger.LogInformation($"Retrieved {tools.Count} MCP tools");
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing MCP tools");
            
            var errorResponse = new ListResponse<McpTool>
            {
                Success = false,
                Error = ex.Message,
                Items = new List<McpTool>(),
                Count = 0
            };

            return StatusCode(500, errorResponse);
        }
    }

    /// <summary>
    /// Get list of available MCP resources
    /// </summary>
    [HttpGet("resources")]
    public async Task<IActionResult> GetResources()
    {
        try
        {
            if (!_mcpService.IsConnected)
            {
                return StatusCode(503, new ListResponse<McpResource>
                {
                    Success = false,
                    Error = "MCP server not connected",
                    Items = new List<McpResource>(),
                    Count = 0
                });
            }

            var resources = await _mcpService.ListResourcesAsync();
            
            var response = new ListResponse<McpResource>
            {
                Success = true,
                Items = resources,
                Count = resources.Count
            };

            _logger.LogInformation($"Retrieved {resources.Count} MCP resources");
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing MCP resources");
            
            var errorResponse = new ListResponse<McpResource>
            {
                Success = false,
                Error = ex.Message,
                Items = new List<McpResource>(),
                Count = 0
            };

            return StatusCode(500, errorResponse);
        }
    }

    /// <summary>
    /// Execute a specific MCP tool
    /// </summary>
    [HttpPost("tools/{toolName}")]
    public async Task<IActionResult> CallTool(string toolName, [FromBody] ToolExecutionRequest request)
    {
        try
        {
            if (!_mcpService.IsConnected)
            {
                return StatusCode(503, new ToolExecutionResponse
                {
                    Success = false,
                    Error = "MCP server not connected",
                    Tool = toolName
                });
            }

            _logger.LogInformation($"🔧 Calling MCP tool: {toolName}");

            // Validate tool exists first
            var availableTools = await _mcpService.ListToolsAsync();
            var tool = availableTools.FirstOrDefault(t => t.Name == toolName);
            
            if (tool == null)
            {
                return NotFound(new ToolExecutionResponse
                {
                    Success = false,
                    Error = $"Tool '{toolName}' not found",
                    Tool = toolName
                });
            }

            var result = await _mcpService.CallToolAsync(toolName, request.Arguments);

            var response = new ToolExecutionResponse
            {
                Success = true,
                Tool = toolName,
                Arguments = request.Arguments,
                Result = result
            };

            _logger.LogInformation($"✅ Tool {toolName} executed successfully");
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"❌ Error calling tool {toolName}");
            
            var errorResponse = new ToolExecutionResponse
            {
                Success = false,
                Error = ex.Message,
                Tool = toolName,
                Arguments = request.Arguments
            };

            return StatusCode(500, errorResponse);
        }
    }

    /// <summary>
    /// Read a specific MCP resource
    /// </summary>
    [HttpGet("resources/{*resourceUri}")]
    public async Task<IActionResult> ReadResource(string resourceUri)
    {
        try
        {
            if (!_mcpService.IsConnected)
            {
                return StatusCode(503, new ResourceResponse
                {
                    Success = false,
                    Error = "MCP server not connected",
                    Uri = resourceUri
                });
            }

            var decodedUri = Uri.UnescapeDataString(resourceUri);
            
            _logger.LogInformation($"📚 Reading MCP resource: {decodedUri}");

            var result = await _mcpService.ReadResourceAsync(decodedUri);

            var response = new ResourceResponse
            {
                Success = true,
                Uri = decodedUri,
                Resource = result
            };

            _logger.LogInformation($"✅ Resource {decodedUri} read successfully");
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"❌ Error reading resource {resourceUri}");
            
            var errorResponse = new ResourceResponse
            {
                Success = false,
                Error = ex.Message,
                Uri = resourceUri
            };

            return StatusCode(500, errorResponse);
        }
    }

    /// <summary>
    /// Execute multiple MCP tools in batch
    /// </summary>
    [HttpPost("tools/batch")]
    public async Task<IActionResult> BatchExecuteTools([FromBody] BatchToolRequest request)
    {
        try
        {
            if (!_mcpService.IsConnected)
            {
                return StatusCode(503, new BatchToolResponse
                {
                    Success = false,
                    Error = "MCP server not connected"
                });
            }

            if (request.Tools == null || !request.Tools.Any())
            {
                return BadRequest(new BatchToolResponse
                {
                    Success = false,
                    Error = "Tools array is required and must not be empty"
                });
            }

            _logger.LogInformation($"🔧 Batch executing {request.Tools.Count} tools");

            var results = new List<McpToolResult>();
            
            foreach (var tool in request.Tools)
            {
                try
                {
                    var result = await _mcpService.CallToolAsync(tool.Name, tool.Arguments);
                    results.Add(new McpToolResult
                    {
                        Tool = tool.Name,
                        Arguments = tool.Arguments,
                        Result = result,
                        Success = true
                    });
                }
                catch (Exception ex)
                {
                    results.Add(new McpToolResult
                    {
                        Tool = tool.Name,
                        Arguments = tool.Arguments,
                        Error = ex.Message,
                        Success = false
                    });
                }
            }

            var successCount = results.Count(r => r.Success);
            var errorCount = results.Count - successCount;

            var response = new BatchToolResponse
            {
                Success = true,
                Results = results,
                Summary = new BatchSummary
                {
                    Total = results.Count,
                    Successful = successCount,
                    Failed = errorCount
                }
            };

            _logger.LogInformation($"✅ Batch execution completed: {successCount} successful, {errorCount} failed");
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in batch tool execution");
            
            var errorResponse = new BatchToolResponse
            {
                Success = false,
                Error = ex.Message,
                Results = new List<McpToolResult>()
            };

            return StatusCode(500, errorResponse);
        }
    }
}
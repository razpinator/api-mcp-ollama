using Microsoft.AspNetCore.Mvc;
using OllamaMcpBridge.Models;
using OllamaMcpBridge.Services;
using System.Text.Json;

namespace OllamaMcpBridge.Controllers;

[ApiController]
[Route("api/chat")]
[Produces("application/json")]
public class ChatController : ControllerBase
{
    private readonly IOllamaService _ollamaService;
    private readonly IMcpService _mcpService;
    private readonly ILogger<ChatController> _logger;

    public ChatController(
        IOllamaService ollamaService, 
        IMcpService mcpService,
        ILogger<ChatController> logger)
    {
        _ollamaService = ollamaService;
        _mcpService = mcpService;
        _logger = logger;
    }

    /// <summary>
    /// Standard chat endpoint with optional MCP integration
    /// </summary>
    [HttpPost("")]
    public async Task<IActionResult> Chat([FromBody] ChatRequest request)
    {
        try
        {
            if (string.IsNullOrEmpty(request.Model) || request.Messages == null || !request.Messages.Any())
            {
                return BadRequest(new ChatResponse
                {
                    Success = false,
                    Error = "Model and messages are required"
                });
            }

            var messages = new List<ChatMessage>(request.Messages);
            var mcpUsed = false;

            // If MCP integration is requested and available
            if (request.UseMCP && _mcpService.IsConnected && request.McpTools.Any())
            {
                _logger.LogInformation($"🔧 Using MCP tools: {string.Join(", ", request.McpTools.Select(t => t.Name))}");
                
                var mcpResults = new List<McpToolResult>();
                
                foreach (var toolCall in request.McpTools)
                {
                    try
                    {
                        _logger.LogInformation($"Executing MCP tool: {toolCall.Name}");
                        var result = await _mcpService.CallToolAsync(toolCall.Name, toolCall.Arguments);
                        mcpResults.Add(new McpToolResult
                        {
                            Tool = toolCall.Name,
                            Arguments = toolCall.Arguments,
                            Result = result,
                            Success = true
                        });
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error executing tool {toolCall.Name}");
                        mcpResults.Add(new McpToolResult
                        {
                            Tool = toolCall.Name,
                            Arguments = toolCall.Arguments,
                            Error = ex.Message,
                            Success = false
                        });
                    }
                }

                // Add MCP results to the conversation context
                var contextMessage = new ChatMessage
                {
                    Role = "system",
                    Content = $"MCP Tool Results:\n{JsonSerializer.Serialize(mcpResults, new JsonSerializerOptions { WriteIndented = true })}\n\nUse this information to answer the user's question."
                };
                
                messages.Insert(0, contextMessage);
                mcpUsed = true;
            }

            // Send to Ollama
            var ollamaRequest = new OllamaChatRequest
            {
                Model = request.Model,
                Messages = messages,
                Stream = false
            };

            var ollamaResponse = await _ollamaService.ChatAsync(ollamaRequest);

            var response = new ChatResponse
            {
                Success = true,
                Response = ollamaResponse,
                McpUsed = mcpUsed
            };

            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in chat endpoint");
            
            var errorResponse = new ChatResponse
            {
                Success = false,
                Error = ex.Message
            };

            return StatusCode(500, errorResponse);
        }
    }

    /// <summary>
    /// Dedicated MCP-enhanced chat endpoint
    /// </summary>
    [HttpPost("mcp")]
    public async Task<IActionResult> McpChat([FromBody] McpChatRequest request)
    {
        try
        {
            if (string.IsNullOrEmpty(request.Model) || request.Messages == null || !request.Messages.Any())
            {
                return BadRequest(new McpChatResponse
                {
                    Success = false,
                    Error = "Model and messages are required"
                });
            }

            if (!_mcpService.IsConnected)
            {
                return StatusCode(503, new McpChatResponse
                {
                    Success = false,
                    Error = "MCP server not connected"
                });
            }

            var messages = new List<ChatMessage>(request.Messages);
            var mcpResults = new List<McpToolResult>();
            
            // Execute requested MCP tools
            if (request.Tools.Any())
            {
                _logger.LogInformation($"🔧 Executing {request.Tools.Count} MCP tools");
                
                foreach (var toolCall in request.Tools)
                {
                    try
                    {
                        var result = await _mcpService.CallToolAsync(toolCall.Name, toolCall.Arguments);
                        mcpResults.Add(new McpToolResult
                        {
                            Tool = toolCall.Name,
                            Arguments = toolCall.Arguments,
                            Result = result,
                            Success = true
                        });
                    }
                    catch (Exception ex)
                    {
                        mcpResults.Add(new McpToolResult
                        {
                            Tool = toolCall.Name,
                            Arguments = toolCall.Arguments,
                            Error = ex.Message,
                            Success = false
                        });
                    }
                }

                // Add tool results to context
                var contextMessage = new ChatMessage
                {
                    Role = "system",
                    Content = $"MCP Tool Execution Results:\n{JsonSerializer.Serialize(mcpResults, new JsonSerializerOptions { WriteIndented = true })}\n\nPlease use this information to provide a comprehensive answer to the user's question."
                };
                
                messages.Insert(0, contextMessage);
            }

            // Send enhanced prompt to Ollama
            var ollamaRequest = new OllamaChatRequest
            {
                Model = request.Model,
                Messages = messages,
                Stream = false
            };

            var ollamaResponse = await _ollamaService.ChatAsync(ollamaRequest);

            var response = new McpChatResponse
            {
                Success = true,
                Response = ollamaResponse,
                McpResults = mcpResults,
                ToolsExecuted = request.Tools.Count
            };

            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in MCP chat endpoint");
            
            var errorResponse = new McpChatResponse
            {
                Success = false,
                Error = ex.Message,
                McpResults = new List<McpToolResult>()
            };

            return StatusCode(500, errorResponse);
        }
    }
}
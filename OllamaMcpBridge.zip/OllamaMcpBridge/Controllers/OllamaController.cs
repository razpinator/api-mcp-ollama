using Microsoft.AspNetCore.Mvc;
using OllamaMcpBridge.Models;
using OllamaMcpBridge.Services;

namespace OllamaMcpBridge.Controllers;

[ApiController]
[Route("api/ollama")]
[Produces("application/json")]
public class OllamaController : ControllerBase
{
    private readonly IOllamaService _ollamaService;
    private readonly ILogger<OllamaController> _logger;

    public OllamaController(IOllamaService ollamaService, ILogger<OllamaController> logger)
    {
        _ollamaService = ollamaService;
        _logger = logger;
    }

    /// <summary>
    /// Get list of available Ollama models
    /// </summary>
    [HttpGet("models")]
    public async Task<IActionResult> GetModels()
    {
        try
        {
            var models = await _ollamaService.GetModelsAsync();
            
            var response = new ListResponse<OllamaModel>
            {
                Success = true,
                Items = models,
                Count = models.Count
            };

            _logger.LogInformation($"Retrieved {models.Count} Ollama models");
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching Ollama models");
            
            var errorResponse = new ListResponse<OllamaModel>
            {
                Success = false,
                Error = ex.Message,
                Items = new List<OllamaModel>(),
                Count = 0
            };

            return StatusCode(500, errorResponse);
        }
    }

    /// <summary>
    /// Check if Ollama service is available
    /// </summary>
    [HttpGet("status")]
    public async Task<IActionResult> GetStatus()
    {
        try
        {
            var isAvailable = await _ollamaService.IsAvailableAsync();
            
            var response = new ApiResponse<object>
            {
                Success = isAvailable,
                Data = new { available = isAvailable, service = "ollama" }
            };

            var statusCode = isAvailable ? 200 : 503;
            return StatusCode(statusCode, response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking Ollama status");
            
            var errorResponse = new ApiResponse<object>
            {
                Success = false,
                Error = ex.Message,
                Data = new { available = false, service = "ollama" }
            };

            return StatusCode(503, errorResponse);
        }
    }
}
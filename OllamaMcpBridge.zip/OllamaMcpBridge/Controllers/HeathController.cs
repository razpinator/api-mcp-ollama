using Microsoft.AspNetCore.Mvc;
using OllamaMcpBridge.Models;
using OllamaMcpBridge.Services;

namespace OllamaMcpBridge.Controllers;

[ApiController]
[Route("api")]
[Produces("application/json")]
public class HealthController : ControllerBase
{
    private readonly IOllamaService _ollamaService;
    private readonly IMcpService _mcpService;
    private readonly ILogger<HealthController> _logger;

    public HealthController(
        IOllamaService ollamaService, 
        IMcpService mcpService,
        ILogger<HealthController> logger)
    {
        _ollamaService = ollamaService;
        _mcpService = mcpService;
        _logger = logger;
    }

    /// <summary>
    /// Get basic API information and available endpoints
    /// </summary>
    [HttpGet("")]
    public IActionResult GetApiInfo()
    {
        var apiInfo = new
        {
            message = "Ollama + MCP Bridge Server is running!",
            timestamp = DateTime.UtcNow,
            endpoints = new
            {
                health = "/api/health",
                ollamaModels = "/api/ollama/models",
                mcpTools = "/api/mcp/tools",
                mcpResources = "/api/mcp/resources",
                callTool = "/api/mcp/tools/{toolName}",
                readResource = "/api/mcp/resources/{resourceUri}",
                chat = "/api/chat",
                chatWithMCP = "/api/chat/mcp",
                batchTools = "/api/mcp/tools/batch"
            }
        };

        return Ok(apiInfo);
    }

    /// <summary>
    /// Get comprehensive health status of all services
    /// </summary>
    [HttpGet("health")]
    public async Task<IActionResult> GetHealth()
    {
        var health = new HealthResponse
        {
            Status = "ok",
            Timestamp = DateTime.UtcNow,
            Services = new Dictionary<string, ServiceHealth>()
        };

        // Check Ollama service
        try
        {
            var models = await _ollamaService.GetModelsAsync();
            health.Services["ollama"] = new ServiceHealth
            {
                Status = "connected",
                Models = models.Count,
                ModelNames = models.Select(m => m.Name).ToList()
            };
            
            _logger.LogInformation($"Ollama health check: {models.Count} models available");
        }
        catch (Exception ex)
        {
            health.Services["ollama"] = new ServiceHealth
            {
                Status = "disconnected",
                Error = ex.Message
            };
            health.Status = "degraded";
            
            _logger.LogWarning(ex, "Ollama health check failed");
        }

        // Check MCP service
        try
        {
            if (_mcpService.IsConnected)
            {
                var tools = await _mcpService.ListToolsAsync();
                var resources = await _mcpService.ListResourcesAsync();
                
                health.Services["mcp"] = new ServiceHealth
                {
                    Status = "connected",
                    Tools = tools.Count,
                    Resources = resources.Count,
                    ToolNames = tools.Select(t => t.Name).ToList()
                };
                
                _logger.LogInformation($"MCP health check: {tools.Count} tools, {resources.Count} resources available");
            }
            else
            {
                health.Services["mcp"] = new ServiceHealth
                {
                    Status = "disconnected"
                };
                health.Status = "degraded";
                
                _logger.LogWarning("MCP health check: not connected");
            }
        }
        catch (Exception ex)
        {
            health.Services["mcp"] = new ServiceHealth
            {
                Status = "disconnected",
                Error = ex.Message
            };
            health.Status = "degraded";
            
            _logger.LogError(ex, "MCP health check failed");
        }

        var statusCode = health.Status == "ok" ? 200 : 503;
        return StatusCode(statusCode, health);
    }
}
using System.Text;
using System.Text.Json;
using OllamaMcpBridge.Models;

namespace OllamaMcpBridge.Services;

public interface IOllamaService
{
    Task<List<OllamaModel>> GetModelsAsync();
    Task<OllamaChatResponse> ChatAsync(OllamaChatRequest request);
    Task<bool> IsAvailableAsync();
}

public class OllamaService : IOllamaService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<OllamaService> _logger;
    private readonly JsonSerializerOptions _jsonOptions;

    public OllamaService(IHttpClientFactory httpClientFactory, ILogger<OllamaService> logger)
    {
        _httpClient = httpClientFactory.CreateClient("Ollama");
        _logger = logger;
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            PropertyNameCaseInsensitive = true
        };
    }

    public async Task<List<OllamaModel>> GetModelsAsync()
    {
        try
        {
            _logger.LogInformation("Fetching Ollama models...");
            
            var response = await _httpClient.GetAsync("/api/tags");
            response.EnsureSuccessStatusCode();
            
            var content = await response.Content.ReadAsStringAsync();
            var modelsResponse = JsonSerializer.Deserialize<OllamaModelsResponse>(content, _jsonOptions);
            
            _logger.LogInformation($"Retrieved {modelsResponse?.Models.Count ?? 0} Ollama models");
            
            return modelsResponse?.Models ?? new List<OllamaModel>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching Ollama models");
            throw new InvalidOperationException($"Failed to connect to Ollama. Make sure Ollama is running on localhost:11434. Error: {ex.Message}", ex);
        }
    }

    public async Task<OllamaChatResponse> ChatAsync(OllamaChatRequest request)
    {
        try
        {
            _logger.LogInformation($"Sending chat request to Ollama model: {request.Model}");
            
            var jsonRequest = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync("/api/chat", content);
            response.EnsureSuccessStatusCode();
            
            var responseContent = await response.Content.ReadAsStringAsync();
            var chatResponse = JsonSerializer.Deserialize<OllamaChatResponse>(responseContent, _jsonOptions);
            
            _logger.LogInformation("Chat request completed successfully");
            
            return chatResponse ?? new OllamaChatResponse();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in Ollama chat request");
            throw new InvalidOperationException($"Ollama chat request failed: {ex.Message}", ex);
        }
    }

    public async Task<bool> IsAvailableAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync("/api/tags");
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }
}
using ModelContextProtocol.Client;
using Microsoft.Extensions.AI;
using OllamaMcpBridge.Models;

namespace OllamaMcpBridge.Services;

public interface IMcpService
{
    Task InitializeAsync();
    Task CloseAsync();
    bool IsConnected { get; }
    Task<List<McpTool>> ListToolsAsync();
    Task<List<McpResource>> ListResourcesAsync();
    Task<object> CallToolAsync(string toolName, Dictionary<string, object> arguments);
    Task<object> ReadResourceAsync(string resourceUri);
}

public class McpService : IMcpService, IAsyncDisposable
{
    private readonly ILogger<McpService> _logger;
    private readonly IConfiguration _configuration;
    private IMcpClient? _mcpClient;
    private bool _isConnected = false;
    private readonly SemaphoreSlim _connectionSemaphore = new(1, 1);
    private IList<McpClientTool>? _availableTools;

    public McpService(ILogger<McpService> logger, IConfiguration configuration)
    {
        _logger = logger;
        _configuration = configuration;
    }

    public bool IsConnected => _isConnected && _mcpClient != null;

    public async Task InitializeAsync()
    {
        await _connectionSemaphore.WaitAsync();
        try
        {
            if (_isConnected && _mcpClient != null)
            {
                return; // Already connected
            }

            _logger.LogInformation("🔄 Initializing MCP HTTP/SSE connection...");

            // Get MCP server configuration for HTTP/SSE connection
            var serverUrl = _configuration["Mcp:ServerUrl"] ?? "http://localhost:8080";
            var sseEndpoint = _configuration["Mcp:SseEndpoint"] ?? "/sse";
            var clientName = _configuration["Mcp:ClientName"] ?? "ollama-mcp-bridge";

            // Construct the full SSE URL
            var baseUri = new Uri(serverUrl);
            var sseUrl = new Uri(baseUri, sseEndpoint);
            
            _logger.LogInformation($"Connecting to MCP server at: {sseUrl}");

            // Create HTTP/SSE transport for the MCP server
            var clientTransport = new SseClientTransport(new SseClientTransportOptions
            {
                Name = clientName,
                Endpoint = sseUrl
            });

            // Create the MCP client using the factory
            _mcpClient = await McpClientFactory.CreateAsync(clientTransport);
            _isConnected = true;

            _logger.LogInformation("✅ MCP HTTP Server connected successfully via SSE");

            // Load available tools and resources for diagnostics
            try
            {
                _availableTools = await _mcpClient.ListToolsAsync();
                var resources = await ListResourcesAsync();
                
                _logger.LogInformation($"🔧 Available MCP tools: {_availableTools?.Count ?? 0}");
                _logger.LogInformation($"📚 Available MCP resources: {resources.Count}");

                if (_availableTools?.Count > 0)
                {
                    _logger.LogInformation($"Available tools: {string.Join(", ", _availableTools.Select(t => t.Name))}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Could not list tools/resources during initialization");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Failed to connect to MCP HTTP server");
            _isConnected = false;
            if (_mcpClient != null)
            {
                await _mcpClient.DisposeAsync();
                _mcpClient = null;
            }
            throw;
        }
        finally
        {
            _connectionSemaphore.Release();
        }
    }

    public async Task<List<McpTool>> ListToolsAsync()
    {
        await EnsureConnectionAsync();
        
        if (_mcpClient == null)
            throw new InvalidOperationException("MCP client is not connected");

        try
        {
            if (_availableTools == null)
            {
                _availableTools = await _mcpClient.ListToolsAsync();
            }

            return _availableTools.Select(t => new McpTool 
            { 
                Name = t.Name, 
                Description = t.Description
                // InputSchema will be populated if the property exists on McpClientTool
                // For now, we'll omit it to avoid compilation errors
            }).ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing MCP tools");
            throw;
        }
    }

    public async Task<List<McpResource>> ListResourcesAsync()
    {
        await EnsureConnectionAsync();
        
        if (_mcpClient == null)
            throw new InvalidOperationException("MCP client is not connected");

        try
        {
            var resources = await _mcpClient.ListResourcesAsync();
            return resources.Select(r => new McpResource 
            { 
                Uri = r.Uri, 
                Name = r.Name,
                Description = r.Description
                // MimeType will be populated if the property exists on the resource type
                // For now, we'll omit it to avoid compilation errors
            }).ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing MCP resources");
            throw;
        }
    }

    public async Task<object> CallToolAsync(string toolName, Dictionary<string, object> arguments)
    {
        await EnsureConnectionAsync();
        
        if (_mcpClient == null)
            throw new InvalidOperationException("MCP client is not connected");

        try
        {
            _logger.LogInformation($"🔧 Calling MCP tool: {toolName} with args: {string.Join(", ", arguments.Keys)}");

            // Find the tool in our available tools
            if (_availableTools == null)
            {
                _availableTools = await _mcpClient.ListToolsAsync();
            }

            var tool = _availableTools.FirstOrDefault(t => t.Name == toolName);
            if (tool == null)
            {
                throw new ArgumentException($"Tool '{toolName}' not found");
            }

            // Call the tool using the MCP client
            var result = await _mcpClient.CallToolAsync(toolName, arguments);
            
            _logger.LogInformation($"✅ Tool {toolName} executed successfully");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"❌ Error calling tool {toolName}");
            throw;
        }
    }

    public async Task<object> ReadResourceAsync(string resourceUri)
    {
        await EnsureConnectionAsync();
        
        if (_mcpClient == null)
            throw new InvalidOperationException("MCP client is not connected");

        try
        {
            _logger.LogInformation($"📚 Reading MCP resource: {resourceUri}");

            var result = await _mcpClient.ReadResourceAsync(resourceUri);
            
            _logger.LogInformation($"✅ Resource {resourceUri} read successfully");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"❌ Error reading resource {resourceUri}");
            throw;
        }
    }

    private async Task EnsureConnectionAsync()
    {
        if (!_isConnected || _mcpClient == null)
        {
            _logger.LogInformation("🔄 Attempting to reconnect to MCP server...");
            await InitializeAsync();
        }
    }

    public async Task CloseAsync()
    {
        await _connectionSemaphore.WaitAsync();
        try
        {
            if (_mcpClient != null)
            {
                await _mcpClient.DisposeAsync();
                _mcpClient = null;
            }
            _isConnected = false;
            _availableTools = null;
        }
        finally
        {
            _connectionSemaphore.Release();
        }
    }

    public async ValueTask DisposeAsync()
    {
        await CloseAsync();
        _connectionSemaphore?.Dispose();
    }
}

// Helper models for MCP entities
public class McpTool
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
}

public class McpResource
{
    public string Uri { get; set; } = string.Empty;
    public string? Name { get; set; }
    public string? Description { get; set; }
}
using Microsoft.OpenApi.Models;
using OllamaMcpBridge.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Configure Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo 
    { 
        Title = "Ollama + MCP Bridge API", 
        Version = "v1.0.0",
        Description = "Bridge between Ollama and Model Context Protocol (MCP) servers"
    });
});

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// Add HttpClient for Ollama communication
builder.Services.AddHttpClient("Ollama", client =>
{
    client.BaseAddress = new Uri("http://localhost:11434");
    client.Timeout = TimeSpan.FromSeconds(30);
});

// Register services
builder.Services.AddSingleton<IMcpService>(provider =>
{
    var logger = provider.GetRequiredService<ILogger<McpService>>();
    var configuration = provider.GetRequiredService<IConfiguration>();
    return new McpService(logger, configuration);
});
builder.Services.AddScoped<IOllamaService, OllamaService>();

// Configure logging
builder.Services.AddLogging(logging =>
{
    logging.AddConsole();
    logging.SetMinimumLevel(LogLevel.Information);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Ollama + MCP Bridge API v1");
        c.RoutePrefix = "swagger";
    });
}

app.UseCors();
app.UseRouting();
app.MapControllers();

// Initialize MCP connection on startup
var mcpService = app.Services.GetRequiredService<IMcpService>();
_ = Task.Run(async () =>
{
    try
    {
        await mcpService.InitializeAsync();
    }
    catch (Exception ex)
    {
        var logger = app.Services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "Failed to initialize MCP connection on startup");
    }
});

// Graceful shutdown
var lifetime = app.Services.GetRequiredService<IHostApplicationLifetime>();
lifetime.ApplicationStopping.Register(async () =>
{
    var logger = app.Services.GetRequiredService<ILogger<Program>>();
    logger.LogInformation("🛑 Shutting down server...");
    
    try
    {
        await mcpService.CloseAsync();
        logger.LogInformation("✅ MCP client closed");
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "❌ Error closing MCP client");
    }
});

Console.WriteLine("🚀 Starting Ollama + MCP API Server...");
Console.WriteLine($"📡 Ollama URL: http://localhost:11434");
Console.WriteLine("🔗 MCP Status: Initializing...");
Console.WriteLine("\n📍 Available Endpoints:");
Console.WriteLine($"   🏥 Health Check: http://localhost:5000/api/health");
Console.WriteLine($"   📋 Ollama Models: http://localhost:5000/api/ollama/models");
Console.WriteLine($"   🔧 MCP Tools: http://localhost:5000/api/mcp/tools");
Console.WriteLine($"   📚 MCP Resources: http://localhost:5000/api/mcp/resources");
Console.WriteLine($"   💬 Chat: http://localhost:5000/api/chat");
Console.WriteLine($"   🤖 MCP Chat: http://localhost:5000/api/chat/mcp");
Console.WriteLine($"   ⚡ Batch Tools: http://localhost:5000/api/mcp/tools/batch");
Console.WriteLine($"   📖 API Docs: http://localhost:5000/swagger");

app.Run();
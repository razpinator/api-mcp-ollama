using System.Text.Json.Serialization;

namespace OllamaMcpBridge.Models;

// Health check models
public class HealthResponse
{
    public string Status { get; set; } = "ok";
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public Dictionary<string, ServiceHealth> Services { get; set; } = new();
}

public class ServiceHealth
{
    public string Status { get; set; } = string.Empty;
    public string? Error { get; set; }
    public int? Models { get; set; }
    public List<string>? ModelNames { get; set; }
    public int? Tools { get; set; }
    public int? Resources { get; set; }
    public List<string>? ToolNames { get; set; }
}

// Chat models
public class ChatRequest
{
    public string Model { get; set; } = string.Empty;
    public List<ChatMessage> Messages { get; set; } = new();
    public bool UseMCP { get; set; } = false;
    public List<McpToolCall> McpTools { get; set; } = new();
}

public class ChatMessage
{
    public string Role { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
}

public class ChatResponse
{
    public bool Success { get; set; }
    public object? Response { get; set; }
    public bool McpUsed { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public string? Error { get; set; }
}

// MCP Tool models
public class McpToolCall
{
    public string Name { get; set; } = string.Empty;
    public Dictionary<string, object> Arguments { get; set; } = new();
}

public class McpToolResult
{
    public string Tool { get; set; } = string.Empty;
    public Dictionary<string, object> Arguments { get; set; } = new();
    public object? Result { get; set; }
    public bool Success { get; set; }
    public string? Error { get; set; }
}

public class ToolExecutionRequest
{
    public Dictionary<string, object> Arguments { get; set; } = new();
}

public class ToolExecutionResponse
{
    public bool Success { get; set; }
    public string Tool { get; set; } = string.Empty;
    public Dictionary<string, object> Arguments { get; set; } = new();
    public object? Result { get; set; }
    public string? Error { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}

public class BatchToolRequest
{
    public List<McpToolCall> Tools { get; set; } = new();
}

public class BatchToolResponse
{
    public bool Success { get; set; }
    public List<McpToolResult> Results { get; set; } = new();
    public BatchSummary Summary { get; set; } = new();
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public string? Error { get; set; }
}

public class BatchSummary
{
    public int Total { get; set; }
    public int Successful { get; set; }
    public int Failed { get; set; }
}

// MCP Chat models
public class McpChatRequest
{
    public string Model { get; set; } = string.Empty;
    public List<ChatMessage> Messages { get; set; } = new();
    public List<McpToolCall> Tools { get; set; } = new();
}

public class McpChatResponse
{
    public bool Success { get; set; }
    public object? Response { get; set; }
    public List<McpToolResult> McpResults { get; set; } = new();
    public int ToolsExecuted { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public string? Error { get; set; }
}

// Resource models
public class ResourceResponse
{
    public bool Success { get; set; }
    public string Uri { get; set; } = string.Empty;
    public object? Resource { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public string? Error { get; set; }
}

// Generic API response models
public class ApiResponse<T>
{
    public bool Success { get; set; }
    public T? Data { get; set; }
    public string? Error { get; set; }
    public string? Details { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}

public class ListResponse<T>
{
    public bool Success { get; set; }
    public List<T> Items { get; set; } = new();
    public int Count { get; set; }
    public string? Error { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}

// Ollama specific models
public class OllamaModel
{
    public string Name { get; set; } = string.Empty;
    public DateTime ModifiedAt { get; set; }
    public long Size { get; set; }
    public string Digest { get; set; } = string.Empty;
}

public class OllamaModelsResponse
{
    public List<OllamaModel> Models { get; set; } = new();
}

public class OllamaChatRequest
{
    public string Model { get; set; } = string.Empty;
    public List<ChatMessage> Messages { get; set; } = new();
    public bool Stream { get; set; } = false;
}

public class OllamaChatResponse
{
    public ChatMessage Message { get; set; } = new();
    public bool Done { get; set; }
    [JsonPropertyName("created_at")]
    public DateTime CreatedAt { get; set; }
}
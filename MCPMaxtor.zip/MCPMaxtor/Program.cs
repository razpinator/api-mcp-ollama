using MCPMaxtor.Services;
using MCPMaxtor.Tools;

var builder = WebApplication.CreateBuilder(args);

// Configure logging
builder.Logging.AddConsole(options =>
{
    options.LogToStandardErrorThreshold = LogLevel.Trace;
});

// Add services
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Add MCP services
builder.Services
    .AddMcpServer()
    .WithToolsFromAssembly();

builder.Services.AddScoped<IMcpService, McpService>();

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors();
app.UseRouting();
app.MapControllers();

// Health check
app.MapGet("/health", () => new { 
    status = "ok", 
    timestamp = DateTime.UtcNow,
    version = "1.0.0"
});

app.MapGet("/", () => "MCP Server is running with HTTP transport");

var port = builder.Configuration.GetValue<int>("Port", 8080);
app.Urls.Add($"http://localhost:{port}");

Console.WriteLine($"🚀 MCP Server starting on http://localhost:{port}");
Console.WriteLine($"🏥 Health: http://localhost:{port}/health");
Console.WriteLine($"📖 Swagger: http://localhost:{port}/swagger");

await app.RunAsync();
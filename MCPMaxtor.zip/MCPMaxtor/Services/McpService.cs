using MCPMaxtor.Models;
using MCPMaxtor.Tools;

namespace MCPMaxtor.Services;

public class McpService : IMcpService
{
    public async Task<IEnumerable<ToolDefinition>> ListToolsAsync()
    {
        return new[]
        {
            new ToolDefinition
            {
                Name = "Echo",
                Description = "Echoes the message back to the client.",
                InputSchema = new
                {
                    type = "object",
                    properties = new
                    {
                        message = new { type = "string", description = "The message to echo" }
                    },
                    required = new[] { "message" }
                }
            }
        };
    }

    public async Task<McpResponse> CallToolAsync(string toolName, Dictionary<string, object> arguments)
    {
        if (toolName.Equals("Echo", StringComparison.OrdinalIgnoreCase))
        {
            if (arguments.TryGetValue("message", out var messageObj) && messageObj?.ToString() is string message)
            {
                var result = EchoTool.Echo(message);
                return new McpResponse
                {
                    Content = new[]
                    {
                        new McpContent { Type = "text", Text = result }
                    }
                };
            }
            throw new ArgumentException("Message parameter is required");
        }
        
        throw new ArgumentException($"Tool '{toolName}' not found");
    }

    public async Task<IEnumerable<object>> ListResourcesAsync()
    {
        return Enumerable.Empty<object>();
    }
}
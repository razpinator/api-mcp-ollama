using MCPMaxtor.Models;

namespace MCPMaxtor.Services;

public interface IMcpService
{
    Task<IEnumerable<ToolDefinition>> ListToolsAsync();
    Task<McpResponse> CallToolAsync(string toolName, Dictionary<string, object> arguments);
    Task<IEnumerable<object>> ListResourcesAsync();
}

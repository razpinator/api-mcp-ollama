namespace MCPMaxtor.Models;

public class McpResponse
{
    public McpContent[] Content { get; set; } = Array.Empty<McpContent>();
}

public class McpContent
{
    public string Type { get; set; } = "text";
    public string Text { get; set; } = string.Empty;
}
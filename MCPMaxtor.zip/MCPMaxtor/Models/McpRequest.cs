using System.Text.Json;

namespace MCPMaxtor.Models;

public class McpToolCallRequest
{
    public Dictionary<string, object> Arguments { get; set; } = new();
}

public class McpListResponse<T>
{
    public IEnumerable<T> Items { get; set; } = Enumerable.Empty<T>();
}
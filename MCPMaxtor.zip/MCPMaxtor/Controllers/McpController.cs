using Microsoft.AspNetCore.Mvc;
using MCPMaxtor.Models;
using MCPMaxtor.Services;

namespace McpHttpServer.Controllers;

[ApiController]
[Route("mcp")]
public class McpController : ControllerBase
{
    private readonly IMcpService _mcpService;
    private readonly ILogger<McpController> _logger;

    public McpController(IMcpService mcpService, ILogger<McpController> logger)
    {
        _mcpService = mcpService;
        _logger = logger;
    }

    [HttpGet("tools")]
    public async Task<ActionResult<McpListResponse<ToolDefinition>>> ListTools()
    {
        try
        {
            var tools = await _mcpService.ListToolsAsync();
            return Ok(new McpListResponse<ToolDefinition> { Items = tools });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing tools");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    [HttpPost("tools/{toolName}")]
    public async Task<ActionResult<McpResponse>> CallTool(string toolName, [FromBody] McpToolCallRequest request)
    {
        try
        {
            var result = await _mcpService.CallToolAsync(toolName, request.Arguments);
            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calling tool {ToolName}", toolName);
            return StatusCode(500, new { error = ex.Message });
        }
    }

    [HttpGet("resources")]
    public async Task<ActionResult<McpListResponse<object>>> ListResources()
    {
        try
        {
            var resources = await _mcpService.ListResourcesAsync();
            return Ok(new McpListResponse<object> { Items = resources });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing resources");
            return StatusCode(500, new { error = ex.Message });
        }
    }
}
using Microsoft.AspNetCore.Mvc;
using MCPMaxtor.Services;

namespace McpHttpServer.Controllers;

[ApiController]
[Route("sse")]
public class SseController : ControllerBase
{
    private readonly IMcpService _mcpService;
    private readonly ILogger<SseController> _logger;

    public SseController(IMcpService mcpService, ILogger<SseController> logger)
    {
        _mcpService = mcpService;
        _logger = logger;
    }

    [HttpGet]
    public async Task HandleSseConnection()
    {
        Response.Headers.Add("Content-Type", "text/event-stream");
        Response.Headers.Add("Cache-Control", "no-cache");
        Response.Headers.Add("Connection", "keep-alive");
        Response.Headers.Add("Access-Control-Allow-Origin", "*");

        _logger.LogInformation("SSE connection established");

        try
        {
            await Response.WriteAsync("event: connected\n");
            await Response.WriteAsync($"data: {{\"timestamp\": \"{DateTime.UtcNow:O}\"}}\n\n");
            await Response.Body.FlushAsync();

            var cancellationToken = HttpContext.RequestAborted;
            while (!cancellationToken.IsCancellationRequested)
            {
                await Response.WriteAsync("event: heartbeat\n");
                await Response.WriteAsync($"data: {{\"timestamp\": \"{DateTime.UtcNow:O}\"}}\n\n");
                await Response.Body.FlushAsync();
                await Task.Delay(30000, cancellationToken);
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("SSE connection cancelled");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in SSE connection");
        }
    }
}